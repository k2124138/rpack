#!/usr/bin/env python3
import json
from pathlib import Path

NAMES = [
    "strikeout", "rhage", "meatball", "frill", "cogwyn", "uriel", "aleph", "elyko",
    "beast", "fray", "nemesis", "clairvoyant", "advent", "excelsus", "menace",
    "travis", "stellar", "corpus", "hatchet", "hex", "nereid", "popstar",
    "scav", "taboo", "strife",
]

TEMPLATE = {
    "parent": "item/generated",
    "textures": {
        "layer0": "item/16x/{name}"
    }
}

def main():
    out_dir = Path(".")  # change if you want a different output folder
    out_dir.mkdir(parents=True, exist_ok=True)

    for name in NAMES:
        data = {
            "parent": TEMPLATE["parent"],
            "textures": {
                "layer0": TEMPLATE["textures"]["layer0"].format(name=name)
            }
        }

        path = out_dir / f"{name}.json"
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
            f.write("\n")

    print(f"Generated {len(NAMES)} json files in: {out_dir.resolve()}")

if __name__ == "__main__":
    main()

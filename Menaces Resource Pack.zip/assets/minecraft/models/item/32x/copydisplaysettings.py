#!/usr/bin/env python3
"""
Batch update Minecraft item model JSON display transforms in the CURRENT folder.

For each *.json file in the current working directory:
- If display.thirdperson_righthand exists:
    copy it to display.thirdperson_lefthand
    and flip the sign of rotation[1] and rotation[2]
- If display.firstperson_righthand exists:
    copy it to display.firstperson_lefthand
    and flip the sign of rotation[1]

Writes changes in-place.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any


def flip_sign(x: Any) -> Any:
    """Return -x for numbers; otherwise return x unchanged."""
    if isinstance(x, (int, float)) and not isinstance(x, bool):
        return -x
    return x


def ensure_rotation_list(obj: dict) -> list | None:
    rot = obj.get("rotation")
    if isinstance(rot, list):
        return rot
    return None


def process_json_data(data: dict) -> bool:
    """
    Mutate data in-place. Return True if changes were made.
    """
    display = data.get("display")
    if not isinstance(display, dict):
        return False

    changed = False

    # thirdperson: copy right -> left, flip rotation[1] and rotation[2]
    tpr = display.get("thirdperson_righthand")
    if isinstance(tpr, dict):
        new_left = copy.deepcopy(tpr)
        rot = ensure_rotation_list(new_left)
        if rot is not None:
            if len(rot) > 1:
                rot[1] = flip_sign(rot[1])
            if len(rot) > 2:
                rot[2] = flip_sign(rot[2])
        display["thirdperson_lefthand"] = new_left
        changed = True

    # firstperson: copy right -> left, flip rotation[1]
    fpr = display.get("firstperson_righthand")
    if isinstance(fpr, dict):
        new_left = copy.deepcopy(fpr)
        rot = ensure_rotation_list(new_left)
        if rot is not None and len(rot) > 1:
            rot[1] = flip_sign(rot[1])
        display["firstperson_lefthand"] = new_left
        changed = True

    return changed


def main() -> int:
    folder = Path.cwd()
    json_files = sorted(folder.glob("*.json"))

    if not json_files:
        print("No .json files found in the current folder.")
        return 0

    updated = 0
    for path in json_files:
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)

            if not isinstance(data, dict):
                continue

            if not process_json_data(data):
                continue

            # Write back (pretty JSON)
            with path.open("w", encoding="utf-8", newline="\n") as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
                f.write("\n")

            updated += 1
            print(f"Updated: {path.name}")

        except json.JSONDecodeError as e:
            print(f"Skip (invalid JSON): {path.name} ({e})")
        except Exception as e:
            print(f"Error processing {path.name}: {e}")

    print(f"Done. Updated {updated} / {len(json_files)} file(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

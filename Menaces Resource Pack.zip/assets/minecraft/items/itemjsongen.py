#!/usr/bin/env python3
"""
Generate Minecraft item model JSON files mapping item -> custom_model_data key.

Creates one file per item named: <itemname>.json
"""

from __future__ import annotations

import json
from pathlib import Path

# Output directory (defaults to ./out). Change as desired.
OUT_DIR = Path("out")

# itemname = custom_model_data_value
# NOTE: You listed diamond_hoe twice; the later one ("strife") wins.
MAPPINGS: dict[str, str] = {
    "stick": "strikeout",
    "iron_hoe": "rhage",
    "trident": "meatball",
    "shears": "frill",
    "warped_fungus_on_a_stick": "cogwyn",
    "diamond_hoe": "strife",
    "netherite_hoe": "aleph",
    "iron_sword": "elyko",
    "disc_fragment_5": "beast",
    "brush": "fray",
    "netherite_shovel": "nemesis",
    "amethyst_shard": "clairvoyant",
    "diamond_sword": "advent",
    "blaze_rod": "menacce",
    "stone_sword": "travis",
    "crossbow": "stellar",
    "player_head": "corpus",
    "iron_axe": "hatchet",
    "raiser_armor_trim_smithing_template": "nereid",
    "chorus_flower": "popstar",
    "brown_shulker_box": "scav",
    "netherite_axe": "taboo",
}

def make_payload(item_name: str, model_name: str) -> dict:
    """
    item_name: minecraft item id (used for fallback model: minecraft:item/<item_name>)
    model_name: name used in 16x/ and 32x/ paths (e.g., strikeout)
    """
    return {
        "model": {
            "type": "minecraft:select",
            "property": "minecraft:custom_model_data",
            "cases": [
                {
                    "when": model_name,
                    "model": {
                        "type": "minecraft:select",
                        "property": "minecraft:display_context",
                        "cases": [
                            {
                                "when": "gui",
                                "model": {
                                    "type": "minecraft:model",
                                    "model": f"minecraft:item/16x/{model_name}",
                                },
                            }
                        ],
                        "fallback": {
                            "type": "minecraft:model",
                            "model": f"item/32x/{model_name}",
                        },
                    },
                }
            ],
            "fallback": {
                "type": "minecraft:model",
                "model": f"minecraft:item/{item_name}",
            },
        }
    }

def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    for item, model in MAPPINGS.items():
        payload = make_payload(item, model)
        out_path = OUT_DIR / f"{item}.json"
        out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    print(f"Wrote {len(MAPPINGS)} files to: {OUT_DIR.resolve()}")

if __name__ == "__main__":
    main()
